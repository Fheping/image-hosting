module.exports = {
    basePath: '../',
    'mock_source': './mock/',
    output: 'output',
    'enable_preview': true,//是否启动浏览器预览 默认 false
    'enable_preview_browser': true,//是否启动浏览器预览 默认 false
    'enable_watch': true,//是否启用更新自动编译 默认  false
    'enable_preview_qrcode': true,//是否使用客户端扫码预览(生成二维码页面) 默认  false
    'enable_log':false,//是否启用日志 默认false
    // 'builderVersion': 'v2.4.0',
    'excludes': [
        'test/**',
        '**/*.xlsx'
    ]
};
