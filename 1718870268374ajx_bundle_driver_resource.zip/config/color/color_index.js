/**
 * 颜色相关配置信息
 */


const saas = require('../../saas/color/color_index.json');
let color_saas = JSON.parse(saas);
color_saas = color_saas.map((color) => {
    const value = color.value.length === 7 ? color.value + 'ff' : color.value;
    return {
        name: `saas_${color.name}`, // 加上saas化私有前缀
        value 
    }
})
export default {
    color: JSON.stringify(color_saas)
};