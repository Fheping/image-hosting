const saas = require("../../saas/color/color_index.json");
let color_saas = JSON.parse(saas);

export function getSaasColor(saasColor) {
  let name = saasColor && saasColor.split("saas_") && saasColor.split("saas_")[1];
  if (!name) {
    return;
  }
  const a = color_saas.find(color => {
    return color.name == name;
  });
  return a.value;
}
