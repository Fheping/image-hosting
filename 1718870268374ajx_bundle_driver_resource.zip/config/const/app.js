/**
 * APP相关配置信息
 */

 const saas = require('../../saas/const/const_app.json');
 let app_info = {};
 try {
    app_info = JSON.parse(saas);
    const nativeCommonParams = JSON.parse(ajx.app.getCommonParam());

    // ajx.app.getCommonParam()
    //  "eid":"客户端中的租户id",
    // "logRootPath:":"客户端中的本地日志根目录",
    // "appName":"客户端中的app名称",
    // "scheme":"客户端中的scheme",
    // "serverHost":"客户端中的服务器地址"
    
    app_info = Object.assign(app_info, nativeCommonParams);
 } catch(e) {}

 export default app_info;