/**
 * 用户协议
 */

const saas = require('../../saas/const/const_user_agreement.json');
const userAgreement = JSON.parse(saas);

export default userAgreement;