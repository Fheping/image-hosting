/**
 * 主流程相关配置项
 */

const saas = require('../../saas/const/const_main.json');
const saasObj = JSON.parse(saas);

export const cancelRules = saasObj.cancelRules;